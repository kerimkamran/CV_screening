DROP TABLE user_preference;
